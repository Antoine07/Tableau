# TP Tableau — El Niño (binômes)

## Démarrage

1. Ouvrir `TP_ETUDIANTS.html` dans un navigateur.
2. Dans Tableau Desktop ou Tableau Public Desktop, choisir **Fichier texte**, puis ouvrir `data/nino34_pedagogique.csv`.
3. Réaliser les cinq étapes du TP et enregistrer un `.twbx`.
4. Pour le formateur uniquement : `corrections/CORRIGE_VISUEL.html`.

## Provenance et prudence scientifique

**Les données distribuées sont simulées et non des mesures NOAA.** Le fichier comporte 312 mois (2000–2025), dont trois valeurs manquantes codées `-9999.0` pour l'apprentissage du nettoyage. Aucune conclusion climatique réelle ne peut être tirée de cette simulation.

Pour substituer une véritable série, utiliser la source NOAA/PSL : https://psl.noaa.gov/data/timeseries/month/Nino34_CPC/ . Vérifier la période, l'unité °C, les versions du jeu de données, la base climatologique et la politique de valeurs manquantes avant comparaison.

## Contenu

- `TP_ETUDIANTS.html` : consignes guidées (5 étapes, binôme, présentation)
- `style.css` : présentation du support et du corrigé
- `data/nino34_pedagogique.csv` : données mensuelles simulées brutes
- `data/nino34_nettoye.csv` : contrôle indépendant des données valides
- `corrections/CORRIGE_VISUEL.html` : graphique temporel, agrégations et réponses attendues

## Note Tableau

Avec la connexion CSV, les filtres et champs calculés fonctionnent sans PostgreSQL. Pour analyser des périodes, utiliser des dates continues à l'échelle mensuelle. Pour l'agrégation annuelle, employer `AVG` plutôt que `SUM` sur l'anomalie.
